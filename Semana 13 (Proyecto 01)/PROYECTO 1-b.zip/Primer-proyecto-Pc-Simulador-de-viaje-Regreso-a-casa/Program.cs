﻿using System;
class ProgramaViajeEspacial
{
    static void Main()
    {
        // Variables del juego
        int combustible = 30;
        int oxigeno = 50;
        int suministros = 40;
        int integridadNave = 100;
        int diasTranscurridos = 0;
        bool juegoTerminado = false;
        // Nombre del capitán
        Console.WriteLine("Bienvenido al Simulador de Viaje Espacial en donde podras divertirte jugando :)");
        Console.Write("Por favor, introduce tu nombre, Capitán: ");
        string nombreCapitan = Console.ReadLine();
        Console.WriteLine($"Capitán {nombreCapitan}, su misión es sobrevivir 10 días en el espacio.");
        // Ciclo del juego
        while (diasTranscurridos < 10 && !juegoTerminado)
        {
            Console.WriteLine($"Día {diasTranscurridos + 1}");
            MostrarEstadoNave(combustible, oxigeno, suministros, integridadNave);
            Console.WriteLine("¿Qué desea hacer hoy?");
            Console.WriteLine("1. Explorar un planeta");
            Console.WriteLine("2. Reparar la nave");
            Console.WriteLine("3. Enviar señales");
            Console.WriteLine("4. Rendirse");
            Console.Write("Seleccione una opción (1-4): ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1": //ene sta parte está la logíca para explorar
                    if (combustible < 15)
                    {
                        Console.WriteLine("No tienes suficiente combustible para explorar.");
                        break;
                    }
                    combustible -= 15;
                    Random rand = new Random();
                    if (rand.Next(100) < 60)
                    {
                        int oxigenoEncontrado = rand.Next(20, 41);
                        oxigeno += oxigenoEncontrado;
                        Console.WriteLine($"Encontraste {oxigenoEncontrado} unidades de oxígeno");
                    }
                    if (rand.Next(100) < 25)
                    {
                        int combustibleEncontrado = rand.Next(10, 31);
                        combustible += combustibleEncontrado;
                        Console.WriteLine($"Encontraste {combustibleEncontrado} unidades de combustible");
                    }
                    if (rand.Next(100) < 50)
                    {
                        int suministrosEncontrados = rand.Next(30, 101);
                        suministros += suministrosEncontrados;
                        Console.WriteLine($"Encontraste {suministrosEncontrados} unidades de suministros");
                    }
                    if (rand.Next(100) < 25)
                    {
                        int daño = rand.Next(10, 21);
                        integridadNave -= daño;
                        if (integridadNave < 0) integridadNave = 0;
                        Console.WriteLine($"Una tormenta eléctrica dañó la nave en un {daño}%.");
                    }
                    if (rand.Next(100) < 25)
                    {
                        int daño = rand.Next(10, 21);
                        integridadNave -= daño;
                        if (integridadNave < 0) integridadNave = 0;
                        Console.WriteLine($"Tuvimos un aterrizaje forzado. La nave sufrió un daño del {daño}%.");
                    }
                    break;
                case "2": // esta es la logíca para reparar la nave 
                    if (integridadNave >= 100)
                    {
                        Console.WriteLine("La nave ya está al 100% de integridad. No necesita reparaciones.");
                        break;
                    }
                    Console.Write("¿Cuánto porcentajes deseas reparar? (1% = 10 suministros): ");
                    string entrada = Console.ReadLine();
                    int porcentajeReparar;
                    if (int.TryParse(entrada, out porcentajeReparar) && porcentajeReparar > 0)
                    {
                        int costo = porcentajeReparar * 10;
                        if (suministros >= costo)
                        {
                            if (integridadNave + porcentajeReparar > 100)
                            {
                                porcentajeReparar = 100 - integridadNave;
                                costo = porcentajeReparar * 10;
                                Console.WriteLine($"Solo puedes reparar hasta el 100%. Se reparará {porcentajeReparar}%.");
                            }
                            suministros -= costo;
                            integridadNave += porcentajeReparar;
                            Console.WriteLine($"Reparaste la nave {porcentajeReparar}%. Suministros restantes: {suministros}");
                        }
                        else
                        {
                            Console.WriteLine("No tienes suficientes suministros para esa reparación.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Entrada no válida.");
                    }
                    break;
                case "3": // aqui es la logíca para enviar señales
                    if (new Random().Next(2) == 0)
                    {
                        combustible += 60;
                        Console.WriteLine("Una nave amiga respondió a tu señal, Recibiste 60 unidades de combustible.");
                    }
                    else
                    {
                        int daño = 15;
                        integridadNave -= daño;
                        if (integridadNave < 0) integridadNave = 0;
                        suministros -= 20;
                        if (suministros < 0) suministros = 0;
                        Console.WriteLine("Piratas espaciales interceptaron tu señal");
                        Console.WriteLine($"Perdiste {daño}% de integridad y 20 suministros.");
                    }
                    break;
                case "4": // esto es para que el jugador si quire pueda rendirse
                    juegoTerminado = true;
                    Console.WriteLine("Ha decidido rendirse. Fin del juego.");
                    continue;
                default:
                    Console.WriteLine("Opción inválida. Intente de nuevo.");
                    continue;
            }
            // Eventos nocturnos y consumo
            if (!juegoTerminado)
            {
                Console.WriteLine("Cae la noche en el espacio...");
                oxigeno -= 20;
                suministros -= 30;
                if (oxigeno < 0) oxigeno = 0;
                if (suministros < 0) suministros = 0;
                Random randNoche = new Random();
                if (randNoche.Next(100) < 15)
                {
                    int tipoEvento = randNoche.Next(3);
                    if (tipoEvento == 0)
                    {
                        oxigeno -= 10;
                        if (oxigeno < 0) oxigeno = 0;
                        Console.WriteLine("Una tormenta cósmica ha afectado la nave. Perdiste 10 de oxígeno.");
                    }
                    else if (tipoEvento == 1)
                    {
                        if (randNoche.Next(2) == 0)
                        {
                            combustible += 20;
                            Console.WriteLine("¡Encuentro alienígena amistoso! Te dieron 20 unidades de combustible.");
                        }
                        else
                        {
                            integridadNave -= 10;
                            if (integridadNave < 0) integridadNave = 0;
                            Console.WriteLine("Encuentro alienígena hostil Perdiste 10% de integridad.");
                        }
                    }
                    else if (tipoEvento == 2)
                    {
                        Console.WriteLine("Una lluvia de meteoritos se aproxima");
                        Console.Write("¿Deseas maniobrar para evitarlos? (s/n): ");
                        string respuesta = Console.ReadLine().ToLower();
                        if (respuesta == "s")
                        {
                            int gasto = randNoche.Next(10, 31);
                            combustible -= gasto;
                            if (combustible < 0) combustible = 0;
                            Console.WriteLine($"Maniobras completadas. Gastaste {gasto} unidades de combustible.");
                        }
                        else
                        {
                            int daño = randNoche.Next(15, 26);
                            integridadNave -= daño;
                            if (integridadNave < 0) integridadNave = 0;
                            Console.WriteLine($"Impacto directo. La nave perdió {daño}% de integridad.");
                        }
                    }
                }
                // Verificar condiciones de derrota
                if (oxigeno <= 0)
                {
                    Console.WriteLine("Te has quedado sin oxígeno, La tripulación no ha sobrevivido.");
                    juegoTerminado = true;
                }
                else if (combustible <= 0)
                {
                    Console.WriteLine("Te has quedado sin combustible, La nave está varada en el espacio.");
                    juegoTerminado = true;
                }
                else if (integridadNave <= 0)
                {
                    Console.WriteLine("La nave ha sido destruida, Misión fallida.");
                    juegoTerminado = true;
                }
                diasTranscurridos++;
                if (diasTranscurridos == 10 && !juegoTerminado)
                {
                    Console.WriteLine("Felicidades, Capitán Has sobrevivido 10 días y has llegado al destino final.");
                    juegoTerminado = true;
                }
            }
        }
        Console.WriteLine("El juego ha terminado. Gracias por jugar.");
    }
    static void MostrarEstadoNave(int combustible, int oxigeno, int suministros, int integridad)
    {
        Console.WriteLine("Estado Actual de la Nave");
        Console.WriteLine($"Combustible: {combustible} unidades");
        Console.WriteLine($"Oxígeno: {oxigeno} unidades");
        Console.WriteLine($"Suministros: {suministros} unidades");
        Console.WriteLine($"Integridad de la nave: {integridad}%");
    }
}